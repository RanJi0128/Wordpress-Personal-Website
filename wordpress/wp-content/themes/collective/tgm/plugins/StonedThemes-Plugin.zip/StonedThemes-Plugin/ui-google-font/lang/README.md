# Translations directory

Use this directory to store .po and .mo files.

This directory can be removed if not used.
